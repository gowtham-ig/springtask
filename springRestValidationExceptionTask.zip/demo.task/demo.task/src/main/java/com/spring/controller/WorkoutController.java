package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Workout;
import com.spring.service.WorkoutService;

import jakarta.validation.Valid;


@RestController
public class WorkoutController {
	
	@Autowired
	WorkoutService workoutService;
	
	@GetMapping("/workouts")
	public List<Workout> getAllWorkouts(){
		return workoutService.getAllWorkouts();
		
	}
	
	@PostMapping("/add")
	public Workout addWorkout(@RequestBody @Valid Workout workout) {
		return workoutService.addWorkout(workout);
	}
	
	@GetMapping("/get/{id}")
	public Workout getWorkoutById(@PathVariable("id") Integer id) throws Exception{
		return workoutService.getWorkoutById(id);
	}
	
	@GetMapping("/home")
	public String getMessage() {
		return "home page";
	}

}
