package com.spring.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.model.Workout;

@Repository
public interface WorkoutRepository extends CrudRepository<Workout,Integer> {
	//all methods available in CrudRepository can be called directly in service.

}
