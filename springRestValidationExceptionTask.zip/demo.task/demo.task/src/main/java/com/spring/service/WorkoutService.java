package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.model.Workout;
import com.spring.repository.WorkoutRepository;
import com.spring.exception.WorkoutNotFoundException;

@Service
public class WorkoutService {
	@Autowired
	WorkoutRepository workoutRepo;
	
	public Workout addWorkout(Workout workout) {
        return workoutRepo.save(workout);
    }

    public List<Workout> getAllWorkouts() {
        return (List)workoutRepo.findAll();
    }
    
    public Workout getWorkoutById(Integer id) {
        return workoutRepo.findById(id)
                .orElseThrow(() -> new WorkoutNotFoundException("Workout not found"));
    }

}
